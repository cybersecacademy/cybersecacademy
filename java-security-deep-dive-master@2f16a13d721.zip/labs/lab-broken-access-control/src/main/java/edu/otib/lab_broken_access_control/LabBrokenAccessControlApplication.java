package edu.otib.lab_broken_access_control;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabBrokenAccessControlApplication {
    public static void main(String[] args) { SpringApplication.run(LabBrokenAccessControlApplication.class, args); }
}
