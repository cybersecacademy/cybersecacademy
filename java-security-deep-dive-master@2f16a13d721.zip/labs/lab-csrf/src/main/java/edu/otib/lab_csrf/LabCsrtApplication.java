package edu.otib.lab_csrf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabCsrtApplication {
    public static void main(String[] args) { SpringApplication.run(LabCsrtApplication.class, args); }
}
