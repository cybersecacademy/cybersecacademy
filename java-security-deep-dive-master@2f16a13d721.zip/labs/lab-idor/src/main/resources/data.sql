INSERT INTO payment (id, username, amount, description) VALUES (1, 'user1', 100, 'TEST payment');
INSERT INTO payment (id, username, amount, description) VALUES (2, 'user2', 100, 'USER2 payment');
INSERT INTO payment (id, username, amount, description) VALUES (3, 'user1', 100, 'user1 TEST payment');
INSERT INTO payment (id, username, amount, description) VALUES (4, 'user2', 100, 'My Secret payment');