package edu.otib.lab_idor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabIdorApplication {
    public static void main(String[] args) { SpringApplication.run(LabIdorApplication.class, args); }
}
