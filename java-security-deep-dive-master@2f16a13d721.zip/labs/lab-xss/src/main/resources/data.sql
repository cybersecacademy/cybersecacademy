INSERT INTO post (id, author, text, created_at) VALUES (1, 'Java News',
    '<b>Java 9</b> Release Now Available!',
    {ts '2017-09-22 14:47:52.69'});
INSERT INTO post (id, author, text, created_at) VALUES (2, 'OWASP',
    'Final Version of 2017 <a href="https://www.owasp.org/index.php/Category:OWASP_Top_Ten_2017_Project">OWASP Top 10</a> Released.',
    {ts '2017-11-21 18:47:52.69'});