package edu.otib.lab_xss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabXSSApplication {

    public static void main(String[] args) { SpringApplication.run(LabXSSApplication.class, args); }
}
